import requests
from pprint import pprint

# Install requests library using pip.
# List of Pokemon IDs.
pokemon_ID = [2, 4, 17, 29, 145, 905]

with open('pokemon.txt', 'w+') as pokemon_file:
    # Loop through list of Pokemon IDs, using API to get the name and move data for each ID, and write data to pokemon.txt file.

    for number in pokemon_ID:
        url = f'https://pokeapi.co/api/v2/pokemon/{number}/'
        response = requests.get(url)
        print(response)
        pokemon = response.json()
        pokemon_name = pokemon['name']
        pokemon_file.write(f'\n{pokemon_name}:\n')
        print(pokemon_name)

        moves = pokemon['moves']
        for move in moves:
            pokemon_move = move['move']['name']
            pokemon_file.write(f'{pokemon_move}\n')
            print(pokemon_move)
